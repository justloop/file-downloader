Plugin Information
--------------------
Plugin Name: Jupload
Author: wftpserver
Author Website: http://www.wftpserver.com
Current Version: 1.0


Description
--------------------
This plugin uses jupload applet for uploading entire folder or files.


Installation
--------------------
Just download the zip file, and extract it into the directory "webclient/plugins/", then there will be a directory "webclient/plugins/jupload".


History
--------------------
Version 1.0	[20/Feb/2011]
* The first working version